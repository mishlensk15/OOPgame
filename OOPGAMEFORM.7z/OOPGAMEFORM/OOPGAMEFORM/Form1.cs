﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPGAMEFORM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Game igra = new Game(max: 100, min: 0);
        string imja;

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Правила гри : компьютер загадує число в дiапазонi вiд 0 до 100, а Ви його вгадуєте.Кожна ваша вiдповiдь змiнює дiапазон чисел.");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            imja = textBox1.Text; 
            igra.rand();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int chislo;
            chislo = Convert.ToInt16(textBox2.Text);
            label4.Text = imja + igra.Otvet(chislo);
        }
    }
}
